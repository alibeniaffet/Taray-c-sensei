# NetAI Browser

Android WebView tabanlı, AI destekli mobil tarayıcı.

## Özellikler

- Çoklu sekme
- Gizli sekme
- Geri / ileri / yenile
- Adres ve Google araması
- Yer imleri
- Geçmiş
- Sayfada bul
- Paylaş
- Masaüstü sitesi
- Dosya yükleme
- İndirme bağlantılarını Android'e devretme
- Açılır pencereler için temel sekme desteği
- Açık / koyu / sistem teması
- Sürüklenebilir AI butonu
- Ana ekran içinde hızlı erişim kartları
- Android ana ekranı için Browser ve AI widget'ları
- Gemini ve Groq API desteği
- Model adı seçme
- AI ile doğal dille site açma
  - Örn. "Bana Hepsiburada'yı aç" → doğrudan https://www.hepsiburada.com
  - Bilinen sitelerde API anahtarı gerekmeden doğrudan açma
  - Diğer isteklerde seçilen AI sağlayıcısı kullanılır

## GitHub ile APK derleme

1. `NetAI-Browser-Project.zip` dosyasını GitHub deposunun köküne yükle.
2. `build.yml` dosyasını `.github/workflows/build.yml` olarak yükle.
3. GitHub → Actions → **Build NetAI Browser APK** → **Run workflow**.
4. İşlem bitince `NetAI-Browser-debug` artifact'ini indir.

API anahtarları projeye gömülmez. Uygulama içindeki Ayarlar > AI bölümünden girilir ve cihazdaki SharedPreferences içinde saklanır.
