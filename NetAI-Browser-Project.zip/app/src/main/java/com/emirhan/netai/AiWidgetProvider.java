package com.emirhan.netai;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

public class AiWidgetProvider extends AppWidgetProvider {
    @Override public void onUpdate(Context c, AppWidgetManager manager, int[] ids) {
        for(int id:ids){
            Intent i=new Intent(c,MainActivity.class).putExtra("open_ai",true);
            PendingIntent p=PendingIntent.getActivity(c,1000+id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget_ai);
            v.setOnClickPendingIntent(R.id.widget_ai,p);
            manager.updateAppWidget(id,v);
        }
    }
}
