package com.emirhan.netai;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.webkit.*;
import android.widget.*;
import org.json.*;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import android.text.TextUtils;

public class MainActivity extends androidx.appcompat.app.AppCompatActivity {

    LinearLayout root, toolbar, bottomBar, homePanel;
    FrameLayout browserFrame;
    EditText address;
    TextView tabCount;
    Button backBtn, forwardBtn, reloadBtn;
    ImageButton aiFab;
    SharedPreferences prefs;
    ArrayList<Tab> tabs = new ArrayList<>();
    int currentTab = 0;
    boolean dark = true;
    boolean desktop = false;
    String theme = "dark";
    final ExecutorService executor = Executors.newSingleThreadExecutor();

    static class Tab {
        WebView web;
        boolean incognito;
        String title = "Yeni sekme";
        Tab(WebView w, boolean i) { web=w; incognito=i; }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("browser", MODE_PRIVATE);
        theme = prefs.getString("theme","dark");
        dark = !"light".equals(theme);
        applyTheme();
        buildUi();
        addTab(false);
        showHome();
        if(getIntent().getBooleanExtra("open_ai",false)) new Handler().postDelayed(this::showAiPanel,250);
    }

    void applyTheme() {
        int c = "light".equals(theme) ? Color.rgb(247,247,249) : Color.rgb(18,18,20);
        getWindow().setStatusBarColor(c);
        getWindow().setNavigationBarColor(c);
        getWindow().getDecorView().setSystemUiVisibility(
                "light".equals(theme) ? View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR : 0);
    }

    int bg() { return "light".equals(theme) ? Color.rgb(247,247,249) : Color.rgb(18,18,20); }
    int panel() { return "light".equals(theme) ? Color.WHITE : Color.rgb(31,31,35); }
    int text() { return "light".equals(theme) ? Color.rgb(25,25,28) : Color.WHITE; }
    int sub() { return "light".equals(theme) ? Color.rgb(95,95,102) : Color.rgb(190,190,195); }

    GradientDrawable rounded(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(r); return g;
    }

    TextView tv(String s, float sp) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(text());
        t.setGravity(Gravity.CENTER_VERTICAL); t.setPadding(12,8,12,8); return t;
    }

    void buildUi() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(bg());
        setContentView(root);

        toolbar = new LinearLayout(this); toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setPadding(8,8,8,5); toolbar.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(toolbar,new LinearLayout.LayoutParams(-1,60));

        Button home = small("⌂");
        toolbar.addView(home,new LinearLayout.LayoutParams(44,50));
        home.setOnClickListener(v->showHome());

        address = new EditText(this);
        address.setSingleLine(true); address.setTextColor(text()); address.setHintTextColor(sub());
        address.setHint("Ara veya web adresi"); address.setTextSize(15); address.setPadding(14,0,10,0);
        address.setBackground(rounded(panel(),50));
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,50,1); ap.setMargins(5,0,5,0);
        toolbar.addView(address,ap);
        address.setOnEditorActionListener((v,id,e)->{navigate(address.getText().toString()); return true;});

        Button menu=small("⋮"); toolbar.addView(menu,new LinearLayout.LayoutParams(48,50));
        menu.setOnClickListener(v->showMenu(v));

        browserFrame = new FrameLayout(this);
        root.addView(browserFrame,new LinearLayout.LayoutParams(-1,0,1));

        bottomBar = new LinearLayout(this); bottomBar.setGravity(Gravity.CENTER);
        bottomBar.setPadding(4,4,4,4); bottomBar.setBackgroundColor(panel());
        root.addView(bottomBar,new LinearLayout.LayoutParams(-1,56));

        backBtn=small("‹"); forwardBtn=small("›"); reloadBtn=small("↻");
        Button tabsBtn=small("▣"); Button plus=small("+");
        for(Button b:new Button[]{backBtn,forwardBtn,reloadBtn,tabsBtn,plus})
            bottomBar.addView(b,new LinearLayout.LayoutParams(0,50,1));
        backBtn.setOnClickListener(v->{if(active()!=null&&active().canGoBack()) active().goBack();});
        forwardBtn.setOnClickListener(v->{if(active()!=null&&active().canGoForward()) active().goForward();});
        reloadBtn.setOnClickListener(v->{if(active()!=null) active().reload();});
        tabsBtn.setOnClickListener(v->showTabs());
        plus.setOnClickListener(v->addTab(false));

        aiFab=new ImageButton(this);
        aiFab.setImageResource(android.R.drawable.ic_menu_search);
        aiFab.setColorFilter(Color.WHITE);
        aiFab.setBackground(rounded(Color.rgb(45,110,240),100));
        FrameLayout.LayoutParams fp=new FrameLayout.LayoutParams(62,62,Gravity.RIGHT|Gravity.BOTTOM);
        fp.setMargins(0,0,18,18); browserFrame.addView(aiFab,fp);
        aiFab.setOnClickListener(v->showAiPanel());
        makeDraggable(aiFab);

        updateColors();
    }

    Button small(String s) {
        Button b=new Button(this); b.setText(s); b.setTextSize(20); b.setTextColor(text());
        b.setAllCaps(false); b.setPadding(0,0,0,0); b.setBackground(rounded(panel(),28)); return b;
    }

    void updateColors() {
        root.setBackgroundColor(bg()); toolbar.setBackgroundColor(bg()); bottomBar.setBackgroundColor(panel());
        address.setTextColor(text()); address.setHintTextColor(sub()); address.setBackground(rounded(panel(),50));
    }

    WebView active(){ return tabs.size()>currentTab ? tabs.get(currentTab).web : null; }

    WebView makeWeb(boolean incognito) {
        WebView w=new WebView(this);
        WebSettings s=w.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
        s.setSupportZoom(true); s.setLoadsImagesAutomatically(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true); s.setSupportMultipleWindows(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        setDesktopUA(s, desktop);
        if(incognito){ s.setCacheMode(WebSettings.LOAD_NO_CACHE); s.setSaveFormData(false); s.setDomStorageEnabled(false); }
        w.setBackgroundColor(bg());
        w.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){ return false; }
            @Override public void onPageFinished(WebView v,String url){
                if(v==active()){ address.setText(url); }
                Tab t=tabs.get(indexOf(v)); if(t!=null){t.title=v.getTitle()==null?url:v.getTitle();}
                if(!tIncognito(v)) saveHistory(url);
            }
        });
        w.setWebChromeClient(new WebChromeClient(){
            @Override public void onReceivedTitle(WebView v,String title){ Tab t=findTab(v); if(t!=null)t.title=title; }
            @Override public boolean onCreateWindow(WebView view, boolean dialog, boolean userGesture, android.os.Message resultMsg) {
                addTab(false);
                WebView.HitTestResult result=view.getHitTestResult();
                return false;
            }
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p){
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*"); startActivityForResult(i,42); fileCallback=cb; return true;
            }
        });
        w.setDownloadListener((url,userAgent,content, mime, len)->{
            Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(url));
            try{startActivity(i);}catch(Exception ignored){}
        });
        w.setOnLongClickListener(v->{ return false; });
        return w;
    }

    ValueCallback<Uri[]> fileCallback;
    @Override protected void onActivityResult(int req,int res,Intent data){
        super.onActivityResult(req,res,data);
        if(req==42&&fileCallback!=null){
            fileCallback.onReceiveValue(res==RESULT_OK&&data!=null?new Uri[]{data.getData()}:null);
            fileCallback=null;
        }
    }

    int indexOf(WebView v){ for(int i=0;i<tabs.size();i++)if(tabs.get(i).web==v)return i; return 0; }
    Tab findTab(WebView v){ for(Tab t:tabs)if(t.web==v)return t; return null; }
    boolean tIncognito(WebView v){ Tab t=findTab(v); return t!=null&&t.incognito; }

    void addTab(boolean incognito){
        WebView w=makeWeb(incognito);
        tabs.add(new Tab(w,incognito)); currentTab=tabs.size()-1;
        browserFrame.removeAllViews(); browserFrame.addView(w,new FrameLayout.LayoutParams(-1,-1));
        addFabToFrame();
        w.requestFocus();
        address.setText("");
    }

    void switchTab(int i){
        if(i<0||i>=tabs.size())return;
        currentTab=i; browserFrame.removeAllViews(); browserFrame.addView(active(),new FrameLayout.LayoutParams(-1,-1));
        addFabToFrame();
        String u=active().getUrl(); address.setText(u==null?"":u);
    }

    void closeTab(int i){
        if(tabs.size()==1){ tabs.get(0).web.loadUrl("about:blank"); showHome(); return; }
        tabs.get(i).web.destroy(); tabs.remove(i); currentTab=Math.max(0,Math.min(currentTab,tabs.size()-1)); switchTab(currentTab);
    }

    void showBrowser(){
        if(active()==null)return;
        browserFrame.removeAllViews();
        browserFrame.addView(active(),new FrameLayout.LayoutParams(-1,-1));
        addFabToFrame();
    }

    void openUrl(String url){
        showBrowser();
        active().loadUrl(url);
    }

    void navigate(String raw){
        if(TextUtils.isEmpty(raw))return;
        showBrowser();
        String s=raw.trim();
        if(s.matches("(?i)https?://.*")) { active().loadUrl(s); return; }
        if(s.matches("(?i)[a-z0-9.-]+\\.[a-z]{2,}(/.*)?")) { active().loadUrl("https://"+s); return; }
        active().loadUrl("https://www.google.com/search?q="+Uri.encode(s));
    }

    void showHome(){
        if(active()==null)return;
        active().loadUrl("about:blank");
        address.setText("");
        TextView h=tv("NetAI Browser",30); h.setGravity(Gravity.CENTER);
        homePanel=new LinearLayout(this); homePanel.setOrientation(LinearLayout.VERTICAL); homePanel.setPadding(22,24,22,20);
        homePanel.setBackgroundColor(bg());
        browserFrame.removeAllViews(); browserFrame.addView(homePanel,new FrameLayout.LayoutParams(-1,-1));
        addFabToFrame();
        homePanel.addView(h,new LinearLayout.LayoutParams(-1,65));
        TextView desc=tv("Hızlı, sade ve yapay zekâ destekli mobil tarayıcı",15); desc.setGravity(Gravity.CENTER);
        homePanel.addView(desc,new LinearLayout.LayoutParams(-1,45));
        EditText q=new EditText(this); q.setHint("Web'de ara..."); q.setSingleLine(); q.setTextColor(text()); q.setHintTextColor(sub());
        q.setBackground(rounded(panel(),50)); q.setPadding(18,0,18,0);
        homePanel.addView(q,new LinearLayout.LayoutParams(-1,55));
        q.setOnEditorActionListener((v,id,e)->{navigate(q.getText().toString());return true;});
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER);
        String[] names={"Google","YouTube","Hepsiburada","Wikipedia"};
        String[] urls={"https://www.google.com","https://www.youtube.com","https://www.hepsiburada.com","https://tr.wikipedia.org"};
        for(int i=0;i<names.length;i++){ final String u=urls[i]; Button b=small(names[i]); row.addView(b,new LinearLayout.LayoutParams(0,54,1)); b.setOnClickListener(v->openUrl(u));}
        homePanel.addView(row,new LinearLayout.LayoutParams(-1,65));
        LinearLayout widgets=new LinearLayout(this); widgets.setOrientation(LinearLayout.VERTICAL);
        widgets.addView(widget("🤖","AI ile konuş","Site aç, ara, özetle veya soru sor",v->showAiPanel()));
        widgets.addView(widget("★","Yer imleri","Kaydettiğin sayfalara hızlı eriş",v->showBookmarks()));
        widgets.addView(widget("◷","Geçmiş","Son ziyaret ettiğin sayfalar",v->showHistory()));
        homePanel.addView(widgets);
    }

    View widget(String icon,String title,String subtext,View.OnClickListener click){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.HORIZONTAL); box.setPadding(14,7,14,7); box.setGravity(Gravity.CENTER_VERTICAL);
        box.setBackground(rounded(panel(),26)); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,70); lp.setMargins(0,5,0,5); box.setLayoutParams(lp);
        TextView i=tv(icon,25); box.addView(i,new LinearLayout.LayoutParams(50,60));
        LinearLayout col=new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL);
        TextView a=tv(title,17); TextView b=tv(subtext,12); b.setTextColor(sub());
        col.addView(a); col.addView(b); box.addView(col,new LinearLayout.LayoutParams(0,-2,1)); box.setOnClickListener(click); return box;
    }

    void showMenu(View anchor){
        PopupMenu p=new PopupMenu(this,anchor);
        String[] items={"Yeni sekme","Gizli sekme","Sekmeler","Yer imlerine ekle","Yer imleri","Geçmiş","Sayfada bul","Paylaş","Masaüstü sitesi","Ayarlar"};
        for(String s:items)p.getMenu().add(s);
        p.setOnMenuItemClickListener(m->{String s=m.getTitle().toString();
            switch(s){
                case "Yeni sekme":addTab(false);showHome();break;
                case "Gizli sekme":addTab(true);showHome();break;
                case "Sekmeler":showTabs();break;
                case "Yer imlerine ekle":bookmark();break;
                case "Yer imleri":showBookmarks();break;
                case "Geçmiş":showHistory();break;
                case "Sayfada bul":findInPage();break;
                case "Paylaş":share();break;
                case "Masaüstü sitesi":desktop=!desktop; for(Tab t:tabs)setDesktopUA(t.web.getSettings(),desktop); if(active()!=null)active().reload(); toast(desktop?"Masaüstü modu açık":"Masaüstü modu kapalı");break;
                case "Ayarlar":settings();break;
            } return true;});
        p.show();
    }

    void setDesktopUA(WebSettings s,boolean d){
        String mobile="Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/125 Mobile Safari/537.36";
        String desk="Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/125 Safari/537.36";
        s.setUserAgentString(d?desk:mobile);
    }

    void showTabs(){
        final Dialog d=new Dialog(this); LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(15,15,15,15); box.setBackground(rounded(bg(),30));
        TextView title=tv("Sekmeler ("+tabs.size()+")",22); box.addView(title,new LinearLayout.LayoutParams(-1,60));
        for(int i=0;i<tabs.size();i++){final int x=i; LinearLayout r=new LinearLayout(this); r.setPadding(10,5,5,5); r.setBackground(rounded(panel(),20));
            TextView t=tv((tabs.get(i).incognito?"🕶 ":"")+" "+(tabs.get(i).title==null?"Yeni sekme":tabs.get(i).title),16); r.addView(t,new LinearLayout.LayoutParams(0,58,1));
            Button close=small("×"); r.addView(close,new LinearLayout.LayoutParams(55,55));
            t.setOnClickListener(v->{switchTab(x);d.dismiss();}); close.setOnClickListener(v->{closeTab(x);d.dismiss();showTabs();});
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,65);lp.setMargins(0,4,0,4);box.addView(r,lp);}
        Button plus=small("+ Yeni sekme"); box.addView(plus,new LinearLayout.LayoutParams(-1,55)); plus.setOnClickListener(v->{addTab(false);showHome();d.dismiss();});
        d.setContentView(box); Window w=d.getWindow(); if(w!=null)w.setBackgroundDrawableResource(android.R.color.transparent); d.show();
    }

    void bookmark(){
        if(active()==null||active().getUrl()==null)return;
        Set<String> s=new LinkedHashSet<>(prefs.getStringSet("bookmarks",new LinkedHashSet<>()));
        s.add(active().getTitle()+"||"+active().getUrl()); prefs.edit().putStringSet("bookmarks",s).apply(); toast("Yer imlerine eklendi");
    }
    void showBookmarks(){ showList("Yer İmleri",new ArrayList<>(prefs.getStringSet("bookmarks",new LinkedHashSet<>())),true); }
    void saveHistory(String url){
        if(url==null||url.startsWith("about:"))return;
        ArrayList<String> h=new ArrayList<>(prefs.getStringSet("history",new LinkedHashSet<>()));
        h.remove(url); h.add(0,url); while(h.size()>100)h.remove(h.size()-1);
        prefs.edit().putStringSet("history",new LinkedHashSet<>(h)).apply();
    }
    void showHistory(){ showList("Geçmiş",new ArrayList<>(prefs.getStringSet("history",new LinkedHashSet<>())),false); }
    void showList(String title,List<String> list,boolean bm){
        final Dialog d=new Dialog(this); LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(15,15,15,15);box.setBackground(rounded(bg(),28));
        box.addView(tv(title,22),new LinearLayout.LayoutParams(-1,55));
        ScrollView sc=new ScrollView(this);LinearLayout rows=new LinearLayout(this);rows.setOrientation(LinearLayout.VERTICAL);
        for(String raw:list){String url=raw,titleText=raw;if(bm&&raw.contains("||")){String[] a=raw.split("\\|\\|",2);titleText=a[0];url=a[1];}
            TextView r=tv(titleText+"\n"+url,14);r.setBackground(rounded(panel(),18));r.setPadding(15,8,15,8);
            r.setOnClickListener(v->{openUrl(url);d.dismiss();});rows.addView(r,new LinearLayout.LayoutParams(-1,65));}
        sc.addView(rows);box.addView(sc,new LinearLayout.LayoutParams(-1,0,1));Button close=small("Kapat");box.addView(close,new LinearLayout.LayoutParams(-1,55));close.setOnClickListener(v->d.dismiss());
        d.setContentView(box);d.show();
    }
    void findInPage(){
        final EditText e=new EditText(this);e.setHint("Sayfada bul");e.setSingleLine();
        new AlertDialog.Builder(this).setTitle("Sayfada bul").setView(e).setPositiveButton("Bul",(d,w)->active().findAllAsync(e.getText().toString())).setNegativeButton("Kapat",null).show();
    }
    void share(){
        if(active()==null)return;Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,active().getUrl());startActivity(Intent.createChooser(i,"Paylaş"));
    }

    void settings(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(20,10,20,10);
        String[] providers={"Gemini","Groq"};
        Spinner provider=new Spinner(this);ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,providers);provider.setAdapter(a);
        provider.setSelection(prefs.getString("provider","Gemini").equals("Groq")?1:0);
        EditText key=new EditText(this);key.setHint("API anahtarı");key.setInputType(129);key.setText(prefs.getString("apiKey",""));
        EditText model=new EditText(this);model.setHint("Model");model.setText(prefs.getString("model","gemini-2.5-flash"));
        Spinner th=new Spinner(this);ArrayAdapter<String>ta=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Sistem varsayılanı","Koyu","Açık"});th.setAdapter(ta);
        String tt=prefs.getString("theme","dark");th.setSelection(tt.equals("light")?2:tt.equals("system")?0:1);
        box.addView(tv("AI sağlayıcısı",14));box.addView(provider);box.addView(tv("API anahtarı (cihazında saklanır)",14));box.addView(key);box.addView(tv("Model adı",14));box.addView(model);box.addView(tv("Tema",14));box.addView(th);
        TextView info=tv("Gemini: generativelanguage.googleapis.com\nGroq: api.groq.com/openai/v1\nModel alanına sağlayıcının hesabında erişimin olan modeli yazabilirsin.",12);info.setTextColor(sub());box.addView(info);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Ayarlar").setView(box).setPositiveButton("Kaydet",(di,w)->{
            String p=provider.getSelectedItem().toString();String m=model.getText().toString().trim();
            prefs.edit().putString("provider",p).putString("apiKey",key.getText().toString().trim()).putString("model",m).apply();
            int x=th.getSelectedItemPosition();theme=x==2?"light":x==0?"system":"dark";prefs.edit().putString("theme",theme).apply();dark=!"light".equals(theme);applyTheme();updateColors();showHome();
        }).setNegativeButton("İptal",null).create();dialog.show();
    }

    void showAiPanel(){
        final Dialog d=new Dialog(this);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(18,12,18,12);box.setBackground(rounded(bg(),28));
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);TextView title=tv("🤖 AI Modu",21);head.addView(title,new LinearLayout.LayoutParams(0,55,1));Button close=small("×");head.addView(close,new LinearLayout.LayoutParams(50,50));box.addView(head);
        ScrollView sc=new ScrollView(this);TextView chat=tv("Ne yapmak istersin?\n\nÖrnek: “Bana Hepsiburada'yı aç.”\n“Google'da Android WebView ara.”\n“Bu sayfayı özetle.”",15);chat.setPadding(8,8,8,8);sc.addView(chat);box.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        EditText input=new EditText(this);input.setHint("AI'ya yaz...");input.setSingleLine(false);input.setTextColor(text());input.setHintTextColor(sub());input.setBackground(rounded(panel(),20));box.addView(input,new LinearLayout.LayoutParams(-1,60));
        Button send=small("Gönder");box.addView(send,new LinearLayout.LayoutParams(-1,55));
        send.setOnClickListener(v->{String q=input.getText().toString().trim();if(q.isEmpty())return;chat.setText(chat.getText()+"\n\nSen: "+q+"\nAI: düşünüyor...");input.setText("");handleAi(q,chat);});
        close.setOnClickListener(v->d.dismiss());
        d.setContentView(box);Window w=d.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.setLayout(-1,-2);}d.show();
    }

    void handleAi(String q,TextView chat){
        String low=q.toLowerCase(Locale.ROOT);
        String url=knownSite(low);
        if(url!=null){openUrl(url);chat.append("\nSiteyi doğrudan açıyorum: "+url);return;}
        if(low.contains("google'da")||low.contains("google da")||low.contains("google'da ara")||low.contains("google da ara")){
            String term=q.replaceAll("(?i).*google.?da( ara)?\\s*","").trim();
            if(!term.isEmpty()){openUrl("https://www.google.com/search?q="+Uri.encode(term));chat.append("\nGoogle'da arıyorum: "+term);return;}
        }
        String key=prefs.getString("apiKey","");
        if(key.isEmpty()){chat.append("\nAPI anahtarı yok. Ayarlar > AI sağlayıcısından Gemini veya Groq anahtarını gir.");return;}
        String provider=prefs.getString("provider","Gemini"), model=prefs.getString("model","gemini-2.5-flash");
        String page=active()!=null&&active().getUrl()!=null?active().getUrl():"";
        executor.execute(()->{
            try{
                String prompt="Sen NetAI Browser içindeki asistansın. Kullanıcının isteğini yerine getir. Eğer bir web sitesini açmasını istiyorsa ve URL'sini biliyorsan cevabın ilk satırı OPEN_URL:https://... olsun. Kullanıcı arama isterse SEARCH:https://www.google.com/search?q=... kullan. Aksi halde normal kısa Türkçe cevap ver. Mevcut sayfa: "+page+"\nİstek: "+q;
                String ans=provider.equals("Groq")?groq(key,model,prompt):gemini(key,model,prompt);
                runOnUiThread(()->{
                    if(ans.startsWith("OPEN_URL:")){String u=ans.substring(9).trim().split("\\s+")[0];openUrl(u);chat.append("\n\nAI: Siteyi açıyorum → "+u);}
                    else if(ans.startsWith("SEARCH:")){String u=ans.substring(7).trim().split("\\s+")[0];openUrl(u);chat.append("\n\nAI: Aramayı açıyorum.");}
                    else chat.append("\n\nAI: "+ans);
                });
            }catch(Exception e){runOnUiThread(()->chat.append("\n\nAI hatası: "+e.getMessage()));}
        });
    }

    String knownSite(String q){
        String[][] sites={
            {"hepsiburada","https://www.hepsiburada.com"},{"hepsiburada'yı","https://www.hepsiburada.com"},{"hepsiburadayi","https://www.hepsiburada.com"},
            {"youtube","https://www.youtube.com"},{"youtube'u","https://www.youtube.com"},{"google","https://www.google.com"},
            {"instagram","https://www.instagram.com"},{"facebook","https://www.facebook.com"},{"x'i","https://x.com"},{"twitter","https://x.com"},
            {"tiktok","https://www.tiktok.com"},{"wikipedia","https://tr.wikipedia.org"},{"trendyol","https://www.trendyol.com"},
            {"github","https://github.com"},{"reddit","https://www.reddit.com"},{"netflix","https://www.netflix.com"},{"amazon","https://www.amazon.com"},
            {"sahibinden","https://www.sahibinden.com"},{"n11","https://www.n11.com"},{"linkedin","https://www.linkedin.com"}
        };
        if(!(q.contains("aç")||q.contains("ac ")||q.contains("git")||q.contains("göster")))return null;
        for(String[] x:sites)if(q.contains(x[0]))return x[1];
        return null;
    }

    String gemini(String key,String model,String prompt)throws Exception{
        URL u=new URL("https://generativelanguage.googleapis.com/v1beta/models/"+URLEncoder.encode(model,"UTF-8")+":generateContent?key="+URLEncoder.encode(key,"UTF-8"));
        JSONObject body=new JSONObject();JSONArray contents=new JSONArray();JSONObject c=new JSONObject();JSONArray parts=new JSONArray();JSONObject p=new JSONObject();p.put("text",prompt);parts.put(p);c.put("parts",parts);contents.put(c);body.put("contents",contents);
        String out=post(u,body.toString(),"application/json");
        JSONObject o=new JSONObject(out);return o.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text").trim();
    }

    String groq(String key,String model,String prompt)throws Exception{
        URL u=new URL("https://api.groq.com/openai/v1/chat/completions");
        JSONObject body=new JSONObject();body.put("model",model);body.put("temperature",0.2);
        JSONArray msgs=new JSONArray();JSONObject sys=new JSONObject();sys.put("role","system");sys.put("content","You are a concise Turkish browser assistant.");msgs.put(sys);
        JSONObject user=new JSONObject();user.put("role","user");user.put("content",prompt);msgs.put(user);body.put("messages",msgs);
        String out=post(u,body.toString(),"application/json","Authorization","Bearer "+key);
        return new JSONObject(out).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim();
    }

    String post(URL u,String body,String type,String... headers)throws Exception{
        HttpURLConnection c=(HttpURLConnection)u.openConnection();c.setRequestMethod("POST");c.setConnectTimeout(15000);c.setReadTimeout(30000);c.setDoOutput(true);c.setRequestProperty("Content-Type",type);
        for(int i=0;i+1<headers.length;i+=2)c.setRequestProperty(headers[i],headers[i+1]);
        OutputStream os=c.getOutputStream();os.write(body.getBytes("UTF-8"));os.close();
        InputStream is=c.getResponseCode()>=400?c.getErrorStream():c.getInputStream();BufferedReader br=new BufferedReader(new InputStreamReader(is));StringBuilder s=new StringBuilder();String line;while((line=br.readLine())!=null)s.append(line);br.close();
        if(c.getResponseCode()>=400)throw new Exception(s.toString());return s.toString();
    }

    void addFabToFrame(){
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(62,62);
        float x=prefs.getFloat("fab_x",-1f), y=prefs.getFloat("fab_y",-1f);
        if(x>=0 && y>=0){ lp.leftMargin=(int)x; lp.topMargin=(int)y; }
        else { lp.gravity=Gravity.RIGHT|Gravity.BOTTOM; lp.setMargins(0,0,18,18); }
        browserFrame.addView(aiFab,lp);
    }

    void makeDraggable(View v){
        v.setOnTouchListener(new View.OnTouchListener(){float dX,dY;long down;
            public boolean onTouch(View view,android.view.MotionEvent e){
                if(e.getAction()==MotionEvent.ACTION_DOWN){dX=view.getX()-e.getRawX();dY=view.getY()-e.getRawY();down=System.currentTimeMillis();return true;}
                if(e.getAction()==MotionEvent.ACTION_MOVE){view.setX(e.getRawX()+dX);view.setY(e.getRawY()+dY);return true;}
                if(e.getAction()==MotionEvent.ACTION_UP){if(System.currentTimeMillis()-down<180)view.performClick();
                    else prefs.edit().putFloat("fab_x",view.getX()).putFloat("fab_y",view.getY()).apply();
                    return true;}return true;
            }});
    }

    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    @Override public void onBackPressed(){if(active()!=null&&active().canGoBack())active().goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){executor.shutdownNow();for(Tab t:tabs)t.web.destroy();super.onDestroy();}
}
